#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "C:\projects\Meson_project\testproject\include\tash.h"

#define FILENAME "Zadacnik.csv"
#define MAX_INPUT_LENGTH 200

//Функция для вывода меню
void print_menu(){
    printf("\n===Manager tasks===\n");
    printf("1. Add a task\n");
    printf("2. Show all tasks\n");
    printf("3. Mark the task as completed\n");
    printf("4. Delete a task\n");
    printf("5. Save tasks to a file\n");
    printf("6. Upload tasks from a file\n");
    printf("0. Exit\n");
    printf("Choose an action:");
}

//Функция для очистки входного буфера
void clear_input_buffer(){
    int c;
    while((c=getchar())!='\n'&& c!=EOF);
}

//Функция для ввода строки с проверкой
int get_input_string(char *buffer,int max_length){
    if(fgets(buffer,max_length,stdin)==NULL){
        return -1;
    }

    //Удаляем символ новой строки
    size_t len=strlen(buffer);
    if(len>0 && buffer[len-1]=='\n'){
        buffer[len-1]='\0';
    }
    return 0;
}
int main(){
    TaskNode* task_list=NULL;
    int choice;
    
    printf("Welcome to the Task Manager!\n");

    //Основной цикл программы
    while(1){
        print_menu();

        if(scanf("%d",&choice)!=1){
            printf("Input error. Please enter a number.\n");
            clear_input_buffer();
            continue;
        }
        clear_input_buffer();
        switch(choice){
            case 0: //Выход
                printf("Exit the program...\n");
                //Очистка памяти перед выходом
                while (task_list!=NULL){
                    TaskNode* temp=task_list;
                    task_list=task_list->next;
                    free(temp);
                }
                return 0;
            case 1:{//Добавить задачу
                char description[MAX_DESCRIPTION_LENGTH];
                char due_date[DATE_LENGTH];

                printf("Enter the task description:");
                if(get_input_string(description,sizeof(description))){
                    printf("Error entering the description.\n");
                    break;
                }
                printf("Enter the due date (YYYY-MM-DD): ");
                if(get_input_string(due_date,sizeof(due_date))){
                    printf("Date entry error.\n");
                    break;
                }

                TaskNode* new_task=create_task(description,due_date);
                if(new_task!=NULL){
                    add_task(&task_list,new_task);
                    printf("The task is completed successfully!\n");
                }else{
                    printf("Error when creating a task.\n");
                }
                break;
            }
            case 2://Показать все задачи
                if (task_list==NULL){
                    printf("The task list is empty.\n");
                }else{
                    printf("\n===Task list===\n");
                    TaskNode* current=task_list;
                    int index=0;
                    while (current!=NULL){
                        print_task(current,index);
                        printf("--------------------\n");
                        current=current->next;
                        index++;
                    }
                }
                break;
            case 3:{//Отметить задачу как выполненную
                if (task_list==NULL){
                    printf("The task list is empty.\n");
                    break;
                }

                int task_index;
                printf("Enter the task number to mark it as completed:");
                if (scanf("%d",&task_index)!=1){
                    printf("Input error.\n");
                    clear_input_buffer();
                    break;
                }
                clear_input_buffer();

                //Поиск задачи по индексу
                TaskNode* current=task_list;
                int current_index=0;
                while(current!=NULL && current_index<task_index){
                    current=current->next;
                    current_index++;
                }
                if (current==NULL){
                    printf("Task with number %d not found.\n",task_index);
                }else{
                    mark_task_completed(current);
                    printf("Task number %d has been marked as completed!\n",task_index);
                }
                break;
            }

            case 4:{//Удачить задачу
                if(task_list==NULL){
                    printf("The list is empty.\n");
                    clear_input_buffer();
                    break;
                }
                
                printf("Current task list:\n");
                TaskNode* current=task_list;
                int index=0;
                while(current!=NULL){
                    print_task(current,index);
                    current=current->next;
                    index++;
                }
                
                int task_num;
                printf("Enter the task number to delete: ");
                scanf("%d", &task_num);
                clear_input_buffer();

                if (task_num < 0 || task_num >= index) {
                    printf("Invalid task number.\n");
                    break;
                }

                delete_task(&task_list, task_num);
                printf("Task number %d has been deleted (if it existed).\n", task_num);
                break;
            }

            case 5://Сохранить задачи в файл
                if (saveTaskToFile("ZADACHI.csv",task_list)==0){
                    printf("The task has been successfully saved to a file '%s'.\n ","ZADACHI.csv");
                }else{
                    printf("Error when saving tasks to a file.\n");
                }
                break;

            case 6://Загрузить задачи из файла
            //Очищаем текущий список перед загрузкой
                while (task_list!=NULL){
                    TaskNode* temp=task_list;
                    task_list=task_list->next;
                    free(temp);
                }


                task_list=loadTaskFromFile("c:/projects/Meson_project/testproject/data/Zadachnik.csv");
                if(task_list!=NULL){
                    printf("The tasks were successfully uploaded from the file '%s'.\n","c:/projects/Meson_project/testproject/data/Zadachnik.csv");
                }else{
                    printf("An error occurred while loading tasks from a file, or the file is empty.\n");
                }
                break;

            default:
                printf("Incorrect selection. Please select an action from 0 to 6.\n");
                break;
        }
    }
    return 0;
}