#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "C:\projects\Meson_project\testproject\include\tash.h"

TaskNode* create_task(const char* description, const char* due_date){
    //Выделяем память под новую задачу
    TaskNode* new_task=(TaskNode*)malloc(sizeof(TaskNode));
    if (new_task==NULL){
        fprintf(stderr,"Error allocating memory for a task\n");
        return NULL;
    }
    //Копируем описание и дату в соответвтующие поля
    strncpy(new_task->description,description,MAX_DESCRIPTION_LENGTH-1);
    new_task->description[MAX_DESCRIPTION_LENGTH-1]='\0';//гарантирует терминирование строки

    strncpy(new_task->due_date,due_date,DATE_LENGTH-1);
    new_task->due_date[DATE_LENGTH-1]='\0';

    new_task->status=PENDING;//начальный статус - НЕВЫПОЛНЕНА
    new_task->next=NULL;//следующий элемент пока отсутсвует

    return new_task;
}

void add_task(TaskNode** head,TaskNode*new_task){
    if (head==NULL|| new_task==NULL){
        return;//Проверка на корректность аргументов
    }
    if (*head==NULL)
    {
        //Если список пууст, новый элемент становится головой списка
        *head=new_task;
    } else{//Если список не пуст — перебирается до конца и добавляется новая задача.
        //Ищем последний элемент списка
        TaskNode* current=*head;
        while (current->next!=NULL){
            current=current->next;
        }
        //Добавляем новый элемент в конец списка
        current->next=new_task;
    }
}

void print_task(const TaskNode* task,int index){
    if (task==NULL){
        printf("Task %d: (null)\n",index);
        return;
    }
    
    const char* status_str;
    switch (task->status){
        case PENDING: status_str="Not completed"; break;
        case COMPLETED:status_str="Completed!"; break;
        default: status_str="Unknown";
    }
    printf("Task %d:\n",index);
    printf(" Description: %s\n", task->description);
    printf(" Deadline: %s\n",task->due_date);
    printf(" Status: %s\n",status_str);
}

void mark_task_completed(TaskNode* task){
    if (task==NULL){
        return;
    }
    task->status=COMPLETED;
}
void delete_task(TaskNode** head,int task_index){//!!!!!
    if(head==NULL || *head==NULL) return;

    TaskNode* current= *head;
    TaskNode* prev=NULL;
    int current_index = 0;

    //Если нужно удалить первый элемент
    if(task_index==0){
        *head=current->next;
        free(current);
        return;
    }
    //Поиск задачи с нужным индексом
    while(current!=NULL && current_index<task_index){
        prev=current;
        current=current->next;
        current_index++;
    }
    //Если задача с таким индексом не найдена
    if(current==NULL)return;

    //Удаление задачи из списка
    prev->next=current->next;
    free(current);
}

