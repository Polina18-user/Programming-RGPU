#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include "C:\projects\Meson_project\testproject\include\tash.h"
//Функция для сохранения списка задач в CSV файл
int saveTaskToFile(const char* filename,TaskNode* head){
    FILE* file=fopen(filename,"w");
    if (!file){
        perror("Error opening the file for writing");
        return -1;
    }
    //Заголовок CSV
    fprintf(file,"Description, Date, Status\n");
    TaskNode* current=head;
    while (current){
        //Отлаживаем программу при наличии "",
        char buffer[1024];
        int j=0;
        for(int i=0; current->description[i]!='\0' && j<(int)(sizeof(buffer)-3); i++){
            if(current->description[i]=='"'){
                buffer[j++]='"';
                buffer[j++]='"';
            }else{
                buffer[j++]=current->description[i];
            }
        }
        buffer[j]='\0';
        //Запись с кавычками, если есть , или .
        fprintf(file,"\"%s\",%s, %s\n",buffer,current->due_date, current->status == COMPLETED ? "completed" : "pending");
    current=current->next;
    }
    fclose(file);
    return 0;
}
TaskNode* loadTaskFromFile(const char* filename){
    FILE* file = fopen(filename, "r");
    if(!file){
        printf("*");
        return NULL;
    }
    
    char line[1024];
    TaskNode *head = NULL, *tail = NULL;

    // Пропускаем заголовок
    fgets(line, sizeof(line), file);

    while(fgets(line, sizeof(line), file)){
        // Убираем \n и \r
        char* newline = strchr(line, '\n');
        if(newline) *newline = '\0';
        char* cr = strchr(line, '\r');
        if(cr) *cr = '\0';
        
        if(strlen(line) == 0) continue;
        
        // Простой парсинг: ищем два последних пробела
        char* p = line + strlen(line) - 1;
        
        // Идем назад до первого пробела (статус)
        while(p > line && *p != ' ') p--;
        if(p == line) continue; // нет пробелов
        
        char* status_start = p + 1;
        *p = '\0';
        
        // Идем дальше до следующего пробела (дата)
        while(p > line && *p != ' ') p--;
        if(p == line) continue;
        
        char* date_start = p + 1;
        *p = '\0';
        
        // Остальное - описание
        char* desc_start = line;
        
        // Убираем пробелы в начале/конце
        while(*desc_start == ' ') desc_start++;
        char* desc_end = desc_start + strlen(desc_start) - 1;
        while(desc_end > desc_start && *desc_end == ' ') *desc_end-- = '\0';
        
        while(*date_start == ' ') date_start++;
        char* date_end = date_start + strlen(date_start) - 1;
        while(date_end > date_start && *date_end == ' ') *date_end-- = '\0';
        
        while(*status_start == ' ') status_start++;
        char* status_end = status_start + strlen(status_start) - 1;
        while(status_end > status_start && *status_end == ' ') *status_end-- = '\0';
        
        // Создаем задачу
        TaskNode* newTask = malloc(sizeof(TaskNode));
        if(newTask){
            strncpy(newTask->description, desc_start, MAX_DESCRIPTION_LENGTH - 1);
            newTask->description[MAX_DESCRIPTION_LENGTH - 1] = '\0';
            
            strncpy(newTask->due_date, date_start, DATE_LENGTH - 1);
            newTask->due_date[DATE_LENGTH - 1] = '\0';
            
            newTask->status = (strcmp(status_start, "completed") == 0) ? COMPLETED : PENDING;
            newTask->next = NULL;
            
            if(!head){
                head = tail = newTask;
            }else{
                tail->next = newTask;
                tail = newTask;
            }
        }
    }
    
    fclose(file);
    return head;
}