#ifndef TASK_H
#define TASK_H
#define MAX_DESCRIPTION_LENGTH 200
#define DATE_LENGTH 11 // YYYY-MM-DD
typedef enum {
    PENDING,
    COMPLETED
    } TaskStatus;
typedef struct TaskNode {
    char description[MAX_DESCRIPTION_LENGTH];
    char due_date[DATE_LENGTH];
    TaskStatus status;
    struct TaskNode* next; // Для реализации связного списка
        } TaskNode;
 // Прототипы функций
TaskNode* create_task(const char* description, const char* due_date);
void add_task(TaskNode** head, TaskNode* new_task);
void print_task(const TaskNode* task, int index);
void mark_task_completed(TaskNode* task);
void delete_task(TaskNode** head, int task_index); // или по ID/описанию
int saveTaskToFile(const char* filename,TaskNode* head);
TaskNode* loadTaskFromFile(const char* filename);
#endif //TASK_H
